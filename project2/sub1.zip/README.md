The implementation of the commands were not too difficult as it is kind of similar to Project 1. The biggest hurdle in this assignment was figuring out what the assignment page wanted me to implement and in what way.

I ended up using argv to parse arguments from the command line and send them to the corresponding operation function.

I tested my code by performing all the functions on the command line. For data transfer operations, I tested various files including .txt, mp3, and jpg.